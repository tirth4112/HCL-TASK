import json
from sqlalchemy import text
from .database import DatabaseManager, PolicyRule
from .embeddings import EmbeddingProvider

class PolicyRepository:
    def __init__(self, db_manager: DatabaseManager, embedding_provider: EmbeddingProvider):
        self.db = db_manager
        self.embeddings = embedding_provider

    def ingest_policy_rules(self, json_path: str) -> int:
        with open(json_path, 'r') as f:
            policies = json.load(f)
        
        session = self.db.get_session()
        count = 0
        try:
            for p in policies:
                # Check if exists
                existing = session.query(PolicyRule).filter_by(policy_id=p['policy_id']).first()
                if not existing:
                    vector = self.embeddings.embed_text(p['policy_text'])
                    new_rule = PolicyRule(
                        policy_id=p['policy_id'],
                        title=p['title'],
                        category=p['category'],
                        policy_text=p['policy_text'],
                        embedding=vector
                    )
                    session.add(new_rule)
                    count += 1
            session.commit()
            return count
        except Exception as e:
            session.rollback()
            raise e
        finally:
            session.close()

    def search_policy(self, query: str, top_k: int = 5) -> list[dict]:
        query_embedding = self.embeddings.embed_text(query)
        session = self.db.get_session()
        try:
            # We use pgvector cosine distance: embedding <=> :query
            results = session.query(
                PolicyRule.policy_id,
                PolicyRule.title,
                PolicyRule.policy_text,
                PolicyRule.embedding.cosine_distance(query_embedding).label("distance")
            ).order_by(PolicyRule.embedding.cosine_distance(query_embedding)).limit(top_k).all()
            
            return [
                {
                    "policy_id": r.policy_id,
                    "title": r.title,
                    "policy_text": r.policy_text,
                    "similarity": 1 - r.distance # Convert distance to similarity
                }
                for r in results
            ]
        finally:
            session.close()
