import json
from groq import Groq
from .config import GROQ_API_KEY, GROQ_MODEL

class GroqLLMProvider:
    def __init__(self, api_key=GROQ_API_KEY, model=GROQ_MODEL):
        if not api_key:
            # We will use mock mode if no api key is present to allow testing without it
            self.mock_mode = True
        else:
            self.mock_mode = False
            self.client = Groq(api_key=api_key)
        self.model = model

    def invoke(self, prompt: str) -> str:
        if self.mock_mode:
            return "This is a mock explanation because no Groq API key was provided. The reasoning follows the deterministic policy engine."
        
        try:
            chat_completion = self.client.chat.completions.create(
                messages=[
                    {
                        "role": "system",
                        "content": "You are a Travel Reimbursement Approval Agent. Use ONLY the supplied policy context and tool results. Never invent policy. Never override deterministic calculations. Return a clear and concise explanation for the decision."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                model=self.model,
                temperature=0.0
            )
            return chat_completion.choices[0].message.content
        except Exception as e:
            return f"Error communicating with LLM: {str(e)}"
